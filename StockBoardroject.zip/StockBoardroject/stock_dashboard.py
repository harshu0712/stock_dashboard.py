import streamlit as st
import yfinance as yf
import pandas as pd
import plotly.graph_objs as go
from ta.momentum import RSIIndicator
from ta.trend import SMAIndicator, EMAIndicator

# Title
st.title("Real-Time Stock Market Dashboard")

# User Input for stock ticker symbol
ticker = st.text_input("Enter stock ticker (e.g. AAPL, MSFT)", "AAPL")

# User Input for date range selection
start_date = st.date_input("Start date", pd.to_datetime("2023-01-01"))
end_date = st.date_input("End date", pd.to_datetime("today"))

if start_date > end_date:
    st.error("Error: End date must fall after start date.")
else:
    # Fetch data
    data = yf.download(ticker, start=start_date, end=end_date)

    if data.empty:
        st.warning("No data found for this ticker and date range.")
    else:
        st.subheader(f"Stock closing prices for {ticker.upper()}")
        st.line_chart(data["Close"])

        # Calculate and display indicators
        data["SMA_20"] = SMAIndicator(data["Close"].squeeze(),window=20).sma_indicator()
        data["EMA_20"] = EMAIndicator(data["Close"], window=20).ema_indicator()
        data["RSI_14"] = RSIIndicator(data["Close"], window=14).rsi()

        # Plot candlestick with indicators
        fig = go.Figure(data=[go.Candlestick(
            x=data.index,
            open=data["Open"],
            high=data["High"],
            low=data["Low"],
            close=data["Close"],
            name="Candlestick"
        )])

        fig.add_trace(go.Scatter(
            x=data.index, y=data["SMA_20"], mode="lines", name="SMA 20"
        ))
        fig.add_trace(go.Scatter(
            x=data.index, y=data["EMA_20"], mode="lines", name="EMA 20"
        ))
        fig.update_layout(title=f"{ticker.upper()} Price Chart with SMA & EMA")

        st.plotly_chart(fig)

        # RSI plot
        st.subheader("Relative Strength Index (RSI)")
        st.line_chart(data["RSI_14"])

